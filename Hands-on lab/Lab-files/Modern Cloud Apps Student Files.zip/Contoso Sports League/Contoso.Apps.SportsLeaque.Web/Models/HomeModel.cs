﻿using System.Collections.Generic;

namespace Contoso.Apps.SportsLeague.Web.Models
{
    public class HomeModel
    {
        public IList<Models.ProductModel> Products { get; set; }
    }
}