﻿using Contoso.Apps.SportsLeague.Data.Models;

namespace Contoso.Apps.SportsLeague.Admin.Models
{
    public class DetailsModel : BaseModel
    {
        public Order Order { get; set; }
    }
}